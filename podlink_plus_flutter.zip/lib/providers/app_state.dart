
import 'package:flutter/material.dart';
import '../models/workout.dart';
import '../models/pod.dart';
import '../models/user.dart';
import '../services/storage_service.dart';

class AppState extends ChangeNotifier {
  final StorageService _storage = StorageService();
  bool _isSignedIn = false;
  bool _isDark = false;
  String _userName = 'Athlete';

  List<Workout> _workouts = const [
    Workout(
      id: 'w1', title: 'Morning Mobility', category: 'Yoga',
      durationMinutes: 20, difficulty: 'Easy',
      description: 'Gentle flow to start your day.',
    ),
    Workout(
      id: 'w2', title: 'HIIT 20: Tabata', category: 'HIIT',
      durationMinutes: 20, difficulty: 'Hard',
      description: '4-minute rounds, max intensity.',
    ),
    Workout(
      id: 'w3', title: '5K Base Run', category: 'Running',
      durationMinutes: 35, difficulty: 'Medium',
      description: 'Steady base pace with warmup.',
    ),
  ];

  List<Pod> _pods = const [
    Pod(id: 'p1', name: 'Zen Stretchers', tagline: 'Find your calm, daily.',
        members: 248, focus: 'Yoga'),
    Pod(id: 'p2', name: 'HIIT Squad', tagline: 'Sweat. Smile. Repeat.',
        members: 531, focus: 'HIIT'),
    Pod(id: 'p3', name: 'City Runners', tagline: 'Pace with your pod.',
        members: 129, focus: 'Running'),
  ];

  UserProfile _profile = const UserProfile(
    id: 'u1', name: 'Athlete', weeklyMinutes: 110, streakDays: 4,
  );

  Future<void> bootstrap() async {
    _isSignedIn = await _storage.getSignedIn();
    _isDark = await _storage.getDarkMode();
    _userName = await _storage.getUserName();
    _profile = _profile.copyWith(name: _userName);
  }

  bool get isSignedIn => _isSignedIn;
  bool get isDark => _isDark;
  UserProfile get profile => _profile;
  List<Workout> get workouts => _workouts;
  List<Pod> get pods => _pods;

  Future<void> signIn() async {
    _isSignedIn = true;
    await _storage.setSignedIn(true);
    notifyListeners();
  }

  Future<void> signOut() async {
    _isSignedIn = false;
    await _storage.setSignedIn(false);
    notifyListeners();
  }

  Future<void> toggleTheme() async {
    _isDark = !_isDark;
    await _storage.setDarkMode(_isDark);
    notifyListeners();
  }

  Future<void> rename(String name) async {
    _userName = name;
    await _storage.setUserName(name);
    _profile = _profile.copyWith(name: name);
    notifyListeners();
  }

  void joinPod(String id) {
    _pods = _pods.map((p) => p.id == id ? p.copyWith(isJoined: true, members: p.members + 1) : p).toList();
    notifyListeners();
  }

  void leavePod(String id) {
    _pods = _pods.map((p) => p.id == id ? p.copyWith(isJoined: false, members: (p.members - 1).clamp(0, 1<<31)) : p).toList();
    notifyListeners();
  }
}
