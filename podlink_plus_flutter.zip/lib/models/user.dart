
class UserProfile {
  final String id;
  final String name;
  final int weeklyMinutes;
  final int streakDays;

  const UserProfile({
    required this.id,
    required this.name,
    required this.weeklyMinutes,
    required this.streakDays,
  });

  UserProfile copyWith({
    String? name,
    int? weeklyMinutes,
    int? streakDays,
  }) {
    return UserProfile(
      id: id,
      name: name ?? this.name,
      weeklyMinutes: weeklyMinutes ?? this.weeklyMinutes,
      streakDays: streakDays ?? this.streakDays,
    );
  }
}
