
class Workout {
  final String id;
  final String title;
  final String category;
  final int durationMinutes;
  final String difficulty;
  final String description;

  const Workout({
    required this.id,
    required this.title,
    required this.category,
    required this.durationMinutes,
    required this.difficulty,
    required this.description,
  });
}
