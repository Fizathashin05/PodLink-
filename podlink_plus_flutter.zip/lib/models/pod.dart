
class Pod {
  final String id;
  final String name;
  final String tagline;
  final int members;
  final String focus; // e.g., 'HIIT', 'Yoga', 'Running'
  final bool isJoined;

  const Pod({
    required this.id,
    required this.name,
    required this.tagline,
    required this.members,
    required this.focus,
    this.isJoined = false,
  });

  Pod copyWith({bool? isJoined, int? members}) => Pod(
    id: id, name: name, tagline: tagline,
    members: members ?? this.members,
    focus: focus, isJoined: isJoined ?? this.isJoined
  );
}
