
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/pod.dart';
import '../../providers/app_state.dart';

class PodCard extends StatelessWidget {
  final Pod pod;
  const PodCard({super.key, required this.pod});

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme;
    return Card(
      child: ListTile(
        leading: CircleAvatar(backgroundColor: color.primaryContainer, child: const Icon(Icons.groups)),
        title: Text(pod.name),
        subtitle: Text('${pod.tagline} • ${pod.members} members • ${pod.focus}'),
        trailing: pod.isJoined
            ? OutlinedButton(
                onPressed: () => context.read<AppState>().leavePod(pod.id),
                child: const Text('Leave'),
              )
            : FilledButton(
                onPressed: () => context.read<AppState>().joinPod(pod.id),
                child: const Text('Join'),
              ),
      ),
    );
  }
}
