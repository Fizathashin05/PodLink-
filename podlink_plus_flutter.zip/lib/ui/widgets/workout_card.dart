
import 'package:flutter/material.dart';
import '../../models/workout.dart';

class WorkoutCard extends StatelessWidget {
  final Workout workout;
  const WorkoutCard({super.key, required this.workout});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 260,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(workout.title, style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 4),
              Text('${workout.category} • ${workout.durationMinutes} min'),
              const Spacer(),
              Align(
                alignment: Alignment.bottomRight,
                child: IconButton(
                  icon: const Icon(Icons.bookmark_add_outlined),
                  onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Saved "${workout.title}" to My Plan (demo).')),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
