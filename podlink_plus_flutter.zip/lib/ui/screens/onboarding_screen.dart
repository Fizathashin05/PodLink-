
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';

class OnboardingScreen extends StatelessWidget {
  const OnboardingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme;
    return Scaffold(
      body: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 48),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Spacer(),
            Icon(Icons.favorite, size: 96, color: color.primary),
            const SizedBox(height: 24),
            Text('PodLink+', style: Theme.of(context).textTheme.displaySmall?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Text('Train together. Stay consistent.', textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: () => context.read<AppState>().signIn(),
                child: const Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Text('Continue'),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text('One-tap sign in (local)', style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}
