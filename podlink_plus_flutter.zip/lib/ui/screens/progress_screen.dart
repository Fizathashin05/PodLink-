
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final profile = context.watch<AppState>().profile;
    return Scaffold(
      appBar: AppBar(title: const Text('Progress')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: ListTile(
                leading: const Icon(Icons.local_fire_department),
                title: const Text('Streak'),
                subtitle: Text('${profile.streakDays} days'),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(Icons.timer),
                title: const Text('Weekly Minutes'),
                subtitle: Text('${profile.weeklyMinutes} min this week'),
              ),
            ),
            const SizedBox(height: 24),
            const Text('Charts coming soon…'),
          ],
        ),
      ),
    );
  }
}
