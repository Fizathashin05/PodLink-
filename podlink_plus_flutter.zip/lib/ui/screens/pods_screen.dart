
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../widgets/pod_card.dart';

class PodsScreen extends StatelessWidget {
  const PodsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pods'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => showDialog(
              context: context,
              builder: (_) => const _CreatePodDialog(),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: state.pods.map((p) => PodCard(pod: p)).toList(),
      ),
    );
  }
}

class _CreatePodDialog extends StatefulWidget {
  const _CreatePodDialog();

  @override
  State<_CreatePodDialog> createState() => _CreatePodDialogState();
}

class _CreatePodDialogState extends State<_CreatePodDialog> {
  final _name = TextEditingController();
  final _tagline = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final state = context.read<AppState>();
    return AlertDialog(
      title: const Text('Create Pod'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'Name')),
          TextField(controller: _tagline, decoration: const InputDecoration(labelText: 'Tagline')),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(
          onPressed: () {
            if (_name.text.isNotEmpty) {
              final id = DateTime.now().millisecondsSinceEpoch.toString();
              final newPod = state.pods.first.copyWith(); // just to borrow structure
              final updated = [
                ...state.pods,
              ];
              updated.add(newPod.copyWith(
                isJoined: true,
                members: 1,
              ));
              // naive: rebuild list by replacing state via reflection is not available;
              // For demo purposes, just show a SnackBar
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Pod "${_name.text}" created (demo).')),
              );
              Navigator.pop(context);
            }
          },
          child: const Text('Create'),
        ),
      ],
    );
  }
}
