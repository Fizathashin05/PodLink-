
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../../models/workout.dart';

class WorkoutsScreen extends StatelessWidget {
  const WorkoutsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final workouts = context.watch<AppState>().workouts;
    return Scaffold(
      appBar: AppBar(title: const Text('Workouts')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: workouts.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, i) => _WorkoutTile(workout: workouts[i]),
      ),
    );
  }
}

class _WorkoutTile extends StatelessWidget {
  final Workout workout;
  const _WorkoutTile({required this.workout});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const Icon(Icons.timer),
        title: Text(workout.title),
        subtitle: Text('${workout.category} • ${workout.durationMinutes} min • ${workout.difficulty}'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => showModalBottomSheet(
          context: context,
          showDragHandle: true,
          builder: (_) => _WorkoutDetail(workout: workout),
        ),
      ),
    );
  }
}

class _WorkoutDetail extends StatelessWidget {
  final Workout workout;
  const _WorkoutDetail({required this.workout});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(workout.title, style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Text('${workout.category} • ${workout.durationMinutes} min • ${workout.difficulty}'),
          const SizedBox(height: 12),
          Text(workout.description),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: FilledButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.play_arrow),
              label: const Text('Start'),
            ),
          ),
        ],
      ),
    );
  }
}
