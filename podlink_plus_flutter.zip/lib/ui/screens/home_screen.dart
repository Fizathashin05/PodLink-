
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/app_state.dart';
import '../widgets/workout_card.dart';
import '../widgets/pod_card.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final color = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text('Hey, ${state.profile.name}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            margin: const EdgeInsets.only(bottom: 16),
            child: ListTile(
              leading: Icon(Icons.local_fire_department, color: color.primary),
              title: const Text('Your streak'),
              subtitle: Text('${state.profile.streakDays} days • ${state.profile.weeklyMinutes} min this week'),
            ),
          ),
          Text('Recommended Workouts', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          SizedBox(
            height: 160,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: state.workouts.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (context, i) => WorkoutCard(workout: state.workouts[i]),
            ),
          ),
          const SizedBox(height: 24),
          Text('Trending Pods', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          ...state.pods.map((p) => PodCard(pod: p)).toList(),
        ],
      ),
    );
  }
}
