
import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static const _kSignedIn = 'signed_in';
  static const _kDarkMode = 'dark_mode';
  static const _kUserName = 'user_name';

  Future<bool> getSignedIn() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getBool(_kSignedIn) ?? false;
  }

  Future<void> setSignedIn(bool value) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setBool(_kSignedIn, value);
  }

  Future<bool> getDarkMode() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getBool(_kDarkMode) ?? false;
  }

  Future<void> setDarkMode(bool value) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setBool(_kDarkMode, value);
  }

  Future<String> getUserName() async {
    final sp = await SharedPreferences.getInstance();
    return sp.getString(_kUserName) ?? 'Athlete';
  }

  Future<void> setUserName(String name) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_kUserName, name);
  }
}
