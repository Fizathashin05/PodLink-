
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/app_state.dart';
import 'theme/app_theme.dart';
import 'ui/screens/onboarding_screen.dart';
import 'ui/screens/shell.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final appState = AppState();
  await appState.bootstrap();
  runApp(PodLinkApp(appState: appState));
}

class PodLinkApp extends StatelessWidget {
  final AppState appState;
  const PodLinkApp({super.key, required this.appState});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: appState,
      child: Consumer<AppState>(
        builder: (context, state, _) {
          return MaterialApp(
            title: 'PodLink+',
            debugShowCheckedModeBanner: false,
            themeMode: state.isDark ? ThemeMode.dark : ThemeMode.light,
            theme: buildLightTheme(),
            darkTheme: buildDarkTheme(),
            home: state.isSignedIn ? const Shell() : const OnboardingScreen(),
          );
        },
      ),
    );
  }
}
