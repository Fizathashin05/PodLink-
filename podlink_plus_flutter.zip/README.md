
# PodLink+ (Flutter)

A fitness-focused social app to discover workouts, join **pods** (micro-communities), track progress, and stay motivated.
Built with **Flutter + Provider** with an emphasis on **UI/UX**, smooth navigation, and delightful micro-interactions.

> Perfect for portfolio upload — clone, run, and showcase!

## ✨ Features
- Onboarding with brand visuals
- Mock auth (one-tap sign-in persistence via `shared_preferences`)
- Bottom navigation: Home · Workouts · Pods · Progress · Profile
- Pod (community) flows: browse pods, view details, join/leave, create a pod
- Workout browsing: categories, details, save to My Plan
- Progress: streaks, weekly minutes, simple charts (placeholder)
- Profile: edit basics (local), theme toggle (light/dark)
- Clean architecture: `models/` · `providers/` · `services/` · `ui/`
- Themed components & responsive layout

## 🛠 Tech
- Flutter, Dart
- Provider (state management)
- Shared Preferences (local persistence)
- Material 3 design language

## 🚀 Quickstart
```bash
# 1) Create a new flutter project (generates android/ios/web)
flutter create podlink_plus
cd podlink_plus

# 2) Replace lib/ and pubspec.yaml with this repo's versions
# (copy the contents of /lib and pubspec.yaml from this zip)

# 3) Get packages & run
flutter pub get
flutter run
```

Alternatively, you can use this repo as-is for GitHub showcase and later run:
```bash
flutter create .
flutter pub get
flutter run
```

## 📂 Structure
```
lib/
  main.dart
  theme/
  models/
  providers/
  services/
  ui/
assets/
  images/
  data/
pubspec.yaml
```

## 🧪 Test
A tiny widget smoke test is included in `test/widget_test.dart`.

## 📸 Assets
All icons use Flutter's default material icons. Image placeholders included.

## 🔒 License
MIT — free to use, modify, and share.
