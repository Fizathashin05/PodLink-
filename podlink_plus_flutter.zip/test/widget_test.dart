
import 'package:flutter_test/flutter_test.dart';
import 'package:podlink_plus/main.dart';
import 'package:podlink_plus/providers/app_state.dart';

void main() {
  testWidgets('smoke test', (tester) async {
    final state = AppState();
    await state.bootstrap();
    await tester.pumpWidget(PodLinkApp(appState: state));
  });
}
